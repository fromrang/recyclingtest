import {useEffect, useState} from 'react';
import axios from 'axios';

function Tr(props){
    const [datas, setDatas] = useState([]);

    useEffect(() => {
        if(props.mode ==='notice'){
            console.log(1);
            axios.get('http://localhost:7878/notice').then((response)=> {
                setDatas(response.data['data']);
            })
        }else if(props.mode === 'sugget'){
            console.log(2);
            axios.get('http://localhost:7878/suggestion').then((response)=> {
                // console.log(response);
                setDatas(response.data['data']);
            })
        }
    
    }, [props.mode]);
    /*
    if(props.mode === 'notice'){
        console.log(1);
        var config = {
            method: 'get',
            url: 'http://localhost:7878/notice',
            headers: { 
                'Content-Type': 'application/json'
            }
        };

    }else if(props.mode === 'sugget'){
        //console.log(2);
        // var config = {
        //     method: 'get',
        //     url: 'http://localhost:7878/suggestion',
        //     headers: { 
        //         'Content-Type': 'application/json'
        //     }
        // };
        

    }
    */
    // axios(config).then(function (response) {
    //     //console.log(response.data['statusCode']);
    //     if (response.data['statusCode'] !== 200){
    //         return alert('잘못된 접근입니다.');
    //     }else{
    //         setDatas(response.data['data']);
    //         // const datas = response.data['data'];
    //         // console.log(datas);
    //         // let id, title, content, regDate = null;
            
    //         // for(let i=0; i<datas.length; i++){
    //         //     console.log(datas[0]);
    //         //     id = i;
    //         //     title = datas[i]['title'];
    //         //     content = datas[i]['content'];
    //         //     regDate = datas[i]['reg_date'];

    //         //     return <tr>
    //         //         <td>id</td>
    //         //         <td>title</td>
    //         //         <td>content</td>
    //         //         <td>regDate</td>
    //         //     </tr>
    //         // }
    //         // // return <div>{title}</div>
    //     }
    // })
    // .catch(function (error) {
    //     console.log(error);
    // });

    const item = (Object.values(datas)).map((item) => (
        <tr key={item.id}>
          <td>{item.id}</td>
          <td>{item.title}</td>
          <td>{item.content}</td>
          <td>{item.reg_date}</td>
        </tr>
    ));
    
    return item;


}

function Notice(){
    const [mode, setMode] = useState("notice");

    return(
        <div>
            <div className="notice_type">
                <div>
                    <a href="/notice" onClick={event=>{
                        event.preventDefault(); 
                        setMode("notice");
                    }}>게시판</a>  
                    <a href="/suggest" onClick={event=>{
                        event.preventDefault();
                        setMode("sugget");
                    }}>기능 제안하기</a>
                </div>
            </div>
            <div className="notice">
            <table className="notice_table">
                <tr className='notice_tr'>
                    <th className="notice_th_id">Id.</th>
                    <th className="notice_th_title">title</th>
                    <th className="notice_th_content">content</th>
                    <th className="notice_th_regDate">reg date</th>
                </tr>
                <Tr mode={mode}/>
            </table>
            </div>
        </div>
    );
}

export default Notice;