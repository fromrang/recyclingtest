import logo from './logo.svg';
import './App.css';

function getLocation() {
  let lat, long;
  if (navigator.geolocation) { // GPS를 지원하면
      navigator.geolocation.getCurrentPosition(function(position) {
          lat = position.coords.latitude;
          long = position.coords.longitude;
          alert('위도 : ' + lat + ' 경도 : ' + long);
      }, function(error) {
          console.error(error);
      }, {
          enableHighAccuracy: false,
          maximumAge: 0,
          timeout: Infinity
      });
  } else {
      alert('GPS를 지원하지 않습니다');
      return;
  }
}

function App() {

  // getLocation();
  
  return (
    
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}

export default App;
